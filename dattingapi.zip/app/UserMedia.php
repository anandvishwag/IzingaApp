<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserMedia extends Model
{
    //
}
